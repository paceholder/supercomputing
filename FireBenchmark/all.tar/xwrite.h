#ifndef XWRITE_H_
#define XWRITE_H_

int write_result(char *inFileName, char *outFileName, int NINTCI, int NINTCF, double *VAR, int ITER, double RATIO);



#endif /* XWRITE_H_ */
